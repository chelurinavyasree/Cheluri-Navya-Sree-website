'use client';

import './globals.css';
import { Inter, Space_Grotesk } from 'next/font/google';
import { ThemeProvider } from '@/components/ThemeProvider';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const spaceGrotesk = Space_Grotesk({ subsets: ['latin'], variable: '--font-space' });

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <title>Cheluri Navya Sree | AI/ML Engineer & Software Developer</title>
        <meta name="description" content="Portfolio of Cheluri Navya Sree — Aspiring AI/ML Engineer, Python Developer, and Software Developer. B.Tech AI & ML student at Annamacharya Institute of Technology and Sciences with CGPA 9.01." />
        <meta name="keywords" content="Cheluri Navya Sree, AI ML Engineer, Machine Learning Student, Python Developer, Software Developer, Artificial Intelligence Student, Computer Vision Developer, Data Structures Algorithms, Java Developer, Edge AI, TinyML, OpenCV, MediaPipe" />
        <meta name="author" content="Cheluri Navya Sree" />
        <meta property="og:title" content="Cheluri Navya Sree | AI/ML Engineer & Software Developer" />
        <meta property="og:description" content="Aspiring AI/ML Engineer and Software Developer passionate about intelligent systems and problem-solving." />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Cheluri Navya Sree | AI/ML Engineer" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>⚡</text></svg>" />
      </head>
      <body className={`${inter.variable} ${spaceGrotesk.variable} font-inter antialiased`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}

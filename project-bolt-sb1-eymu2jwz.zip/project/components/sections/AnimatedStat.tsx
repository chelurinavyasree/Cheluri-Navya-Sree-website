'use client';

import { motion, useInView, animate } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';

interface AnimatedStatProps {
  value: number;
  suffix?: string;
  label: string;
  delay?: number;
}

export function AnimatedStat({ value, suffix = '', label, delay = 0 }: AnimatedStatProps) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-50px' });
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, value, {
      duration: 1.5,
      delay,
      ease: 'easeOut',
      onUpdate(v) {
        setDisplay(Number(v.toFixed(value % 1 === 0 ? 0 : 2)));
      },
    });
    return () => controls.stop();
  }, [inView, value, delay]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.4, delay }}
      className="glass rounded-2xl p-4 text-center"
    >
      <div className="font-space text-2xl font-bold gradient-text-bright md:text-3xl">
        {display}
        {suffix}
      </div>
      <div className="mt-1 text-xs text-muted-foreground md:text-sm">{label}</div>
    </motion.div>
  );
}

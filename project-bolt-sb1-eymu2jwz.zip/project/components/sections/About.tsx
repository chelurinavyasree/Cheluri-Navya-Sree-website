'use client';

import Image from 'next/image';
import { motion } from 'framer-motion';
import { GraduationCap, Code2, Lightbulb, Briefcase } from 'lucide-react';
import { PERSONAL, STATS } from '@/lib/data';
import { AnimatedStat } from './AnimatedStat';

export function About() {
  return (
    <section id="about" className="section-padding">
      <div className="mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h2 className="font-space text-3xl font-bold md:text-5xl">
            About <span className="gradient-text">Me</span>
          </h2>
          <div className="mx-auto mt-4 h-1 w-20 rounded-full bg-gradient-to-r from-primary to-accent" />
        </motion.div>

        <div className="grid items-center gap-12 lg:grid-cols-5">
          {/* Profile photo */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-2"
          >
            <div className="relative mx-auto max-w-sm">
              {/* Glow behind photo */}
              <div className="absolute inset-0 -z-10 animate-pulse-glow rounded-[2rem] bg-gradient-to-br from-primary/40 to-accent/30 blur-2xl" />

              {/* Photo frame */}
              <div className="relative overflow-hidden rounded-[2rem] glass-strong p-3">
                <div className="overflow-hidden rounded-[1.5rem]">
                  <Image
                    src="/WhatsApp_Image_2026-07-03_at_18.00.34.jpeg"
                    alt="Cheluri Navya Sree — AI/ML Engineer"
                    width={500}
                    height={600}
                    className="h-auto w-full object-cover object-top"
                    priority
                  />
                </div>
              </div>

              {/* Floating badge — top right */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -right-4 top-8 flex items-center gap-2 rounded-2xl glass-strong px-4 py-3 shadow-lg"
              >
                <GraduationCap className="h-5 w-5 text-primary" />
                <span className="text-sm font-semibold">AI & ML Student</span>
              </motion.div>

              {/* Floating badge — bottom left */}
              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -left-4 bottom-10 flex items-center gap-2 rounded-2xl glass-strong px-4 py-3 shadow-lg"
              >
                <Code2 className="h-5 w-5 text-accent" />
                <span className="text-sm font-semibold">Developer</span>
              </motion.div>
            </div>
          </motion.div>

          {/* About content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="lg:col-span-3"
          >
            <h3 className="font-space text-2xl font-bold md:text-3xl">
              Artificial Intelligence & Machine Learning Student
            </h3>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground md:text-lg">
              I am <span className="font-semibold text-foreground">{PERSONAL.name}</span>, a B.Tech
              student specializing in Artificial Intelligence and Machine Learning at{' '}
              <span className="font-semibold text-foreground">
                Annamacharya Institute of Technology and Sciences
              </span>{' '}
              with a CGPA of 9.01.
            </p>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground md:text-lg">
              I have a strong interest in Artificial Intelligence, Machine Learning, Software
              Development, Data Science, Computer Vision, Natural Language Processing, and Data
              Analytics. I enjoy developing practical applications and solving real-world problems
              using Python, Java, SQL, machine learning, and modern software development
              technologies.
            </p>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground md:text-lg">
              I am a quick learner, adaptable, and passionate about continuously improving my
              technical and analytical skills. I am looking for internship, placement, and
              full-time opportunities where I can contribute to meaningful projects, learn from
              experienced professionals, and grow as an AI/ML Engineer or Software Developer.
            </p>

            <div className="mt-6 flex flex-wrap gap-3">
              <div className="flex items-center gap-2 rounded-full glass px-4 py-2 text-sm">
                <Lightbulb className="h-4 w-4 text-primary" />
                Problem Solving
              </div>
              <div className="flex items-center gap-2 rounded-full glass px-4 py-2 text-sm">
                <Briefcase className="h-4 w-4 text-accent" />
                Open to Opportunities
              </div>
            </div>

            {/* Stats */}
            <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {STATS.map((stat, i) => (
                <AnimatedStat key={i} {...stat} delay={i * 0.1} />
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

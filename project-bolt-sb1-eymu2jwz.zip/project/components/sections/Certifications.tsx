'use client';

import { motion } from 'framer-motion';
import { BadgeCheck, Calendar, Award, Code2, Briefcase, Star, Hash } from 'lucide-react';
import { CERTIFICATIONS } from '@/lib/data';

export function Certifications() {
  return (
    <section id="certifications" className="section-padding">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h2 className="font-space text-3xl font-bold md:text-5xl">
            Certifi<span className="gradient-text">cations</span>
          </h2>
          <div className="mx-auto mt-4 h-1 w-20 rounded-full bg-gradient-to-r from-primary to-accent" />
        </motion.div>

        <div className="space-y-6">
          {CERTIFICATIONS.map((cert, i) => (
            <CertCard key={i} cert={cert} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function CertCard({ cert, index }: { cert: typeof CERTIFICATIONS[number]; index: number }) {
  const isFeatured = cert.type === 'capstone' || cert.type === 'fellowship';

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      whileHover={{ y: -4 }}
      className={`group relative overflow-hidden rounded-3xl transition-all hover:glow-border ${
        isFeatured ? 'glass-strong border border-primary/20' : 'glass'
      }`}
    >
      {/* Featured background shimmer */}
      {isFeatured && (
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/8 via-transparent to-accent/8" />
      )}

      <div className="p-6 md:p-8">
        <div className="flex flex-col gap-6 md:flex-row md:items-start">
          {/* Icon */}
          <div
            className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${
              cert.type === 'capstone'
                ? 'bg-gradient-to-br from-amber-400/20 to-orange-500/20'
                : cert.type === 'fellowship'
                ? 'bg-gradient-to-br from-primary/20 to-accent/20'
                : 'bg-primary/10'
            }`}
          >
            {cert.type === 'capstone' ? (
              <Award className="h-7 w-7 text-amber-500" />
            ) : cert.type === 'fellowship' ? (
              <Star className="h-7 w-7 text-primary" />
            ) : (
              <BadgeCheck className="h-7 w-7 text-primary" />
            )}
          </div>

          {/* Main content */}
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="font-space text-lg font-bold leading-tight md:text-xl">
                  {cert.name}
                </h3>
                <p className="mt-1 text-sm font-semibold text-primary">{cert.organization}</p>
              </div>

              {/* Badges row */}
              <div className="flex flex-wrap gap-2">
                {cert.date && (
                  <span className="flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
                    <Calendar className="h-3 w-3" />
                    {cert.date}
                  </span>
                )}
                {cert.grade && (
                  <span className="flex items-center gap-1.5 rounded-full bg-green-500/10 px-3 py-1 text-xs font-semibold text-green-500">
                    <Award className="h-3 w-3" />
                    Grade: {cert.grade}
                  </span>
                )}
                {cert.duration && (
                  <span className="rounded-full bg-accent/10 px-3 py-1 text-xs font-semibold text-accent">
                    {cert.duration}
                  </span>
                )}
              </div>
            </div>

            {/* Description for fellowship */}
            {'description' in cert && cert.description && (
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {cert.description}
              </p>
            )}

            {/* Project title (capstone) */}
            {cert.projectTitle && (
              <div className="mt-3 flex items-start gap-2 rounded-xl bg-background/50 p-3">
                <Briefcase className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Project
                  </span>
                  <p className="mt-0.5 text-sm font-semibold">{cert.projectTitle}</p>
                </div>
              </div>
            )}

            {/* Role */}
            {cert.role && (
              <div className="mt-2 flex items-center gap-2 text-sm text-muted-foreground">
                <Briefcase className="h-4 w-4 text-primary" />
                <span>Role: <span className="font-semibold text-foreground">{cert.role}</span></span>
              </div>
            )}

            {/* Technologies */}
            {cert.technologies && cert.technologies.length > 0 && (
              <div className="mt-4">
                <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  <Code2 className="h-3.5 w-3.5" />
                  Technologies Used
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {cert.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="rounded-md border border-border bg-background/50 px-2 py-1 text-xs font-medium"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Skills */}
            {cert.skills && cert.skills.length > 0 && (
              <div className="mt-4">
                <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  <BadgeCheck className="h-3.5 w-3.5" />
                  Skills Demonstrated
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {cert.skills.map((skill) => (
                    <span
                      key={skill}
                      className="flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary"
                    >
                      <span className="h-1 w-1 rounded-full bg-primary" />
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* CIN */}
            {cert.cin && (
              <div className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
                <Hash className="h-3 w-3" />
                CIN: {cert.cin}
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

'use client';

import { motion } from 'framer-motion';
import { Trophy, Medal, Star } from 'lucide-react';
import { ACHIEVEMENTS } from '@/lib/data';

export function Achievements() {
  return (
    <section id="achievements" className="section-padding">
      <div className="mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h2 className="font-space text-3xl font-bold md:text-5xl">
            Achieve<span className="gradient-text">ments</span>
          </h2>
          <div className="mx-auto mt-4 h-1 w-20 rounded-full bg-gradient-to-r from-primary to-accent" />
        </motion.div>

        <div className="space-y-5">
          {ACHIEVEMENTS.map((ach, i) => {
            const isFeatured = ach.icon === 'fellowship';
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                whileHover={{ y: -4 }}
                className={`group relative overflow-hidden rounded-2xl transition-all hover:glow-border ${
                  isFeatured
                    ? 'glass-strong border border-primary/20'
                    : 'glass'
                }`}
              >
                {isFeatured && (
                  <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/8 via-transparent to-accent/8" />
                )}
                <div className="flex items-start gap-4 p-5 md:p-6">
                  <div
                    className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${
                      ach.icon === 'fellowship'
                        ? 'bg-gradient-to-br from-primary/25 to-accent/20'
                        : 'bg-gradient-to-br from-amber-400/20 to-orange-400/20'
                    }`}
                  >
                    {ach.icon === 'fellowship' ? (
                      <Star className="h-7 w-7 text-primary" />
                    ) : ach.icon === 'ncc' ? (
                      <Trophy className="h-7 w-7 text-amber-500" />
                    ) : (
                      <Medal className="h-7 w-7 text-amber-500" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-3">
                      <h3 className="font-space text-base font-bold md:text-lg">{ach.title}</h3>
                      {ach.year && (
                        <span className="rounded-full bg-primary/10 px-3 py-0.5 text-xs font-semibold text-primary">
                          {ach.year}
                        </span>
                      )}
                    </div>
                    <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                      {ach.description}
                    </p>
                    {ach.icon === 'fellowship' && (
                      <div className="mt-3 flex flex-wrap gap-2">
                        {['DSA', 'Python', 'Java', 'DevOps', 'Git', 'GitHub'].map((tag) => (
                          <span
                            key={tag}
                            className="rounded-md border border-primary/30 bg-primary/5 px-2 py-0.5 text-xs font-medium text-primary"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

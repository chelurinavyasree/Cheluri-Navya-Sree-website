'use client';

import { motion } from 'framer-motion';
import { Eye, Database, Leaf, Mic, BarChart3, CheckSquare, ScanFace } from 'lucide-react';

interface ProjectVisualProps {
  type: 'ai' | 'database' | 'agriculture' | 'voice' | 'sorting' | 'task' | 'concentration';
}

export function ProjectVisual({ type }: ProjectVisualProps) {
  const visuals: Record<string, React.ReactNode> = {
    ai: (
      <div className="relative h-full w-full bg-gradient-to-br from-primary/30 via-accent/20 to-background">
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0.8, 0.5] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="absolute h-32 w-32 rounded-full border-2 border-primary/30"
          />
          <motion.div
            animate={{ scale: [1.1, 1, 1.1], opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
            className="absolute h-24 w-24 rounded-full border-2 border-accent/40"
          />
          <Eye className="h-16 w-16 text-primary" />
        </div>
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-1.5 w-1.5 rounded-full bg-primary"
            style={{
              top: `${20 + Math.random() * 60}%`,
              left: `${20 + Math.random() * 60}%`,
            }}
            animate={{ opacity: [0, 1, 0] }}
            transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
          />
        ))}
      </div>
    ),
    database: (
      <div className="relative h-full w-full bg-gradient-to-br from-accent/30 via-primary/15 to-background">
        <div className="absolute inset-0 flex items-center justify-center gap-3">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 2, repeat: Infinity, delay: i * 0.2 }}
              className="flex h-16 w-20 items-center justify-center rounded-lg border-2 border-primary/40 glass"
            >
              <Database className="h-6 w-6 text-primary" />
            </motion.div>
          ))}
        </div>
        {[...Array(4)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-0.5 w-12 bg-primary/30"
            style={{ top: '50%', left: '20%' }}
            animate={{ scaleX: [0, 1, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.3 }}
          />
        ))}
      </div>
    ),
    agriculture: (
      <div className="relative h-full w-full bg-gradient-to-br from-green-500/20 via-primary/15 to-background">
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            animate={{ y: [0, -15, 0], rotate: [0, 5, -5, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
          >
            <Leaf className="h-16 w-16 text-green-500" />
          </motion.div>
        </div>
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-2 w-2 rounded-full bg-green-400/60"
            style={{
              bottom: '10%',
              left: `${10 + i * 10}%`,
            }}
            animate={{ y: [0, -5, 0], opacity: [0.4, 0.8, 0.4] }}
            transition={{ duration: 2, repeat: Infinity, delay: i * 0.15 }}
          />
        ))}
        <motion.div
          className="absolute right-4 top-4 h-8 w-8 rounded-full border-2 border-primary/40"
          animate={{ rotate: 360 }}
          transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
        />
      </div>
    ),
    voice: (
      <div className="relative h-full w-full bg-gradient-to-br from-primary/25 via-accent/20 to-background">
        <div className="absolute inset-0 flex items-center justify-center">
          <Mic className="h-16 w-16 text-primary" />
        </div>
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute bottom-1/2 left-1/2 w-1 rounded-full bg-primary/50"
            style={{ transformOrigin: 'bottom' }}
            animate={{ scaleY: [0.5, 1.5, 0.5] }}
            transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.1 }}
          />
        ))}
        {[...Array(4)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full border border-primary/30"
            style={{ top: '50%', left: '50%', width: '40px', height: '40px' }}
            animate={{ scale: [1, 2, 1], opacity: [0.5, 0, 0.5] }}
            transition={{ duration: 2, repeat: Infinity, delay: i * 0.5 }}
          />
        ))}
      </div>
    ),
    sorting: (
      <div className="relative h-full w-full bg-gradient-to-br from-accent/25 via-primary/15 to-background">
        <div className="absolute inset-0 flex items-end justify-center gap-1.5 pb-6">
          {[40, 70, 30, 90, 55, 75, 45].map((h, i) => (
            <motion.div
              key={i}
              className="w-6 rounded-t-md bg-gradient-to-t from-primary to-accent"
              animate={{ height: [`${h}%`, `${h * 0.5}%`, `${h}%`] }}
              transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.1 }}
            />
          ))}
        </div>
        <div className="absolute left-4 top-4">
          <BarChart3 className="h-8 w-8 text-primary/60" />
        </div>
      </div>
    ),
    task: (
      <div className="relative h-full w-full bg-gradient-to-br from-primary/25 via-accent/15 to-background">
        <div className="absolute inset-0 flex items-center justify-center">
          <CheckSquare className="h-16 w-16 text-primary" />
        </div>
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute left-1/2 flex items-center gap-2 rounded-lg glass px-3 py-2"
            style={{ top: `${25 + i * 20}%`, transform: 'translateX(-50%)' }}
            animate={{ x: ['-50%', '-40%', '-50%'] }}
            transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
          >
            <div className="h-3 w-3 rounded border-2 border-primary" />
            <div className="h-1.5 w-16 rounded bg-muted-foreground/30" />
          </motion.div>
        ))}
      </div>
    ),
    concentration: (
      <div className="relative h-full w-full bg-gradient-to-br from-primary/25 via-accent/20 to-background">
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <ScanFace className="h-16 w-16 text-primary" />
          </motion.div>
        </div>
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-1 w-1 rounded-full bg-accent"
            style={{
              top: `${30 + Math.random() * 40}%`,
              left: `${30 + Math.random() * 40}%`,
            }}
            animate={{ opacity: [0, 1, 0], scale: [1, 2, 1] }}
            transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.2 }}
          />
        ))}
        <motion.div
          className="absolute left-1/2 top-1/2 h-20 w-20 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-accent/40"
          animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </div>
    ),
  };

  return <>{visuals[type]}</>;
}

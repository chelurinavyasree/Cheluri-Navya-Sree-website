'use client';

import { motion } from 'framer-motion';
import { Download, Eye, FileText } from 'lucide-react';
import { PERSONAL } from '@/lib/data';

export function Resume() {
  return (
    <section id="resume" className="section-padding">
      <div className="mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h2 className="font-space text-3xl font-bold md:text-5xl">
            Res<span className="gradient-text">ume</span>
          </h2>
          <div className="mx-auto mt-4 h-1 w-20 rounded-full bg-gradient-to-r from-primary to-accent" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.5 }}
          className="glass-strong relative overflow-hidden rounded-3xl p-8 md:p-12"
        >
          <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-primary/10 blur-3xl" />
          <div className="absolute -left-10 -bottom-10 h-40 w-40 rounded-full bg-accent/10 blur-3xl" />

          <div className="relative flex flex-col items-center text-center">
            <div className="mb-6 flex h-20 w-16 items-center justify-center rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 shadow-lg">
              <FileText className="h-10 w-10 text-primary" />
            </div>
            <h3 className="font-space text-xl font-bold md:text-2xl">My Resume</h3>
            <p className="mt-2 max-w-md text-sm text-muted-foreground md:text-base">
              Download or preview my complete resume with details about my education, skills,
              projects, and certifications.
            </p>

            <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
              <a
                href={PERSONAL.resumeUrl}
                download
                className="group flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/30 transition-all hover:scale-105 hover:shadow-primary/50"
              >
                <Download className="h-4 w-4 transition-transform group-hover:translate-y-0.5" />
                Download Resume
              </a>
              <a
                href={PERSONAL.resumeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-2 rounded-full glass px-6 py-3 text-sm font-semibold transition-all hover:scale-105 hover:glow-border"
              >
                <Eye className="h-4 w-4" />
                Preview Resume
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

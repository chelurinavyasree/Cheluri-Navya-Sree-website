'use client';

import { motion } from 'framer-motion';
import { Github, ExternalLink, Calendar, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import { PROJECTS, type Project } from '@/lib/data';
import { ProjectVisual } from './ProjectVisual';

export function Projects() {
  const [expanded, setExpanded] = useState<number | null>(null);

  return (
    <section id="projects" className="section-padding">
      <div className="mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h2 className="font-space text-3xl font-bold md:text-5xl">
            Proj<span className="gradient-text">ects</span>
          </h2>
          <div className="mx-auto mt-4 h-1 w-20 rounded-full bg-gradient-to-r from-primary to-accent" />
        </motion.div>

        <div className="grid gap-6 md:grid-cols-2">
          {PROJECTS.map((project, i) => (
            <ProjectCard
              key={i}
              project={project}
              index={i}
              expanded={expanded === i}
              onToggle={() => setExpanded(expanded === i ? null : i)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

function ProjectCard({
  project,
  index,
  expanded,
  onToggle,
}: {
  project: Project;
  index: number;
  expanded: boolean;
  onToggle: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      className="group glass-strong overflow-hidden rounded-3xl transition-all hover:glow-border"
    >
      {/* Visual */}
      <div className="relative h-48 overflow-hidden">
        <ProjectVisual type={project.visual} />
        <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
        <div className="absolute left-4 top-4 flex items-center gap-2 rounded-full glass px-3 py-1 text-xs font-semibold">
          <Calendar className="h-3 w-3 text-primary" />
          {project.year}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        <h3 className="font-space text-lg font-bold leading-tight">{project.title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{project.description}</p>

        {/* Tech badges */}
        <div className="mt-4 flex flex-wrap gap-1.5">
          {project.technologies.slice(0, 4).map((tech) => (
            <span
              key={tech}
              className="rounded-md bg-primary/10 px-2 py-1 text-xs font-medium text-primary"
            >
              {tech}
            </span>
          ))}
          {project.technologies.length > 4 && (
            <span className="rounded-md bg-muted px-2 py-1 text-xs font-medium text-muted-foreground">
              +{project.technologies.length - 4} more
            </span>
          )}
        </div>

        {/* Expandable features */}
        <button
          onClick={onToggle}
          className="mt-4 flex items-center gap-1 text-sm font-semibold text-primary transition-colors hover:text-accent"
        >
          {expanded ? 'Hide Features' : 'View Features'}
          <ChevronRight
            className={`h-4 w-4 transition-transform ${expanded ? 'rotate-90' : ''}`}
          />
        </button>

        <motion.div
          initial={false}
          animate={{ height: expanded ? 'auto' : 0, opacity: expanded ? 1 : 0 }}
          transition={{ duration: 0.3 }}
          className="overflow-hidden"
        >
          <ul className="mt-4 space-y-2">
            {project.features.map((feature, j) => (
              <li key={j} className="flex items-start gap-2 text-sm text-muted-foreground">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                {feature}
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Links */}
        {(project.github || project.demo) && (
          <div className="mt-5 flex gap-3">
            {project.github && (
              <a
                href={project.github}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 rounded-full glass px-4 py-2 text-xs font-semibold transition-all hover:scale-105"
              >
                <Github className="h-4 w-4" />
                Code
              </a>
            )}
            {project.demo && (
              <a
                href={project.demo}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 rounded-full glass px-4 py-2 text-xs font-semibold transition-all hover:scale-105"
              >
                <ExternalLink className="h-4 w-4" />
                Live Demo
              </a>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}

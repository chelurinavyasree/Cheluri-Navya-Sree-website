'use client';

import { motion } from 'framer-motion';
import { Heart, Mail, Phone, MapPin } from 'lucide-react';
import { PERSONAL, NAV_LINKS } from '@/lib/data';

export function Footer() {
  const handleClick = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-border/50 py-12">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="grid gap-8 md:grid-cols-3">
          <div>
            <h3 className="font-space text-lg font-bold">
              <span className="gradient-text-bright">{PERSONAL.displayName}</span>
            </h3>
            <p className="mt-2 text-sm text-muted-foreground">{PERSONAL.title}</p>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              Quick Links
            </h4>
            <div className="flex flex-wrap gap-x-4 gap-y-2">
              {NAV_LINKS.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleClick(link.href)}
                  className="text-sm text-muted-foreground transition-colors hover:text-primary"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              Contact
            </h4>
            <div className="space-y-2 text-sm">
              <a href={`mailto:${PERSONAL.email}`} className="flex items-center gap-2 text-muted-foreground transition-colors hover:text-primary">
                <Mail className="h-4 w-4" />
                {PERSONAL.email}
              </a>
              <a href={`tel:${PERSONAL.phone}`} className="flex items-center gap-2 text-muted-foreground transition-colors hover:text-primary">
                <Phone className="h-4 w-4" />
                {PERSONAL.phone}
              </a>
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="h-4 w-4" />
                {PERSONAL.location}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-border/50 pt-6 text-center">
          <p className="flex items-center justify-center gap-1.5 text-sm text-muted-foreground">
            Made with <Heart className="h-4 w-4 fill-red-500 text-red-500" /> by {PERSONAL.name}
          </p>
        </div>
      </div>
    </footer>
  );
}

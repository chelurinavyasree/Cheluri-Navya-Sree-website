'use client';

import { motion } from 'framer-motion';
import { GraduationCap, MapPin, Award } from 'lucide-react';
import { EDUCATION } from '@/lib/data';

export function Education() {
  return (
    <section id="education" className="section-padding">
      <div className="mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h2 className="font-space text-3xl font-bold md:text-5xl">
            Edu<span className="gradient-text">cation</span>
          </h2>
          <div className="mx-auto mt-4 h-1 w-20 rounded-full bg-gradient-to-r from-primary to-accent" />
        </motion.div>

        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-4 top-0 h-full w-0.5 bg-gradient-to-b from-primary via-accent to-transparent md:left-1/2 md:-translate-x-1/2" />

          {EDUCATION.map((edu, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: i % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className={`relative mb-8 pl-12 md:w-1/2 md:pl-0 ${
                i % 2 === 0 ? 'md:pr-12 md:text-right' : 'md:ml-auto md:pl-12'
              }`}
            >
              {/* Dot */}
              <div
                className={`absolute top-4 left-4 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30 md:left-auto ${
                  i % 2 === 0 ? 'md:-right-4' : 'md:-left-4'
                }`}
              >
                <GraduationCap className="h-4 w-4" />
              </div>

              <div className="glass-strong rounded-2xl p-6 transition-all hover:glow-border">
                <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
                  {edu.duration}
                </span>
                <h3 className="mt-3 font-space text-lg font-bold">{edu.degree}</h3>
                {edu.branch && edu.branch !== edu.institution && (
                  <p className="text-sm text-accent">{edu.branch}</p>
                )}
                <p className="mt-1 text-sm font-medium text-foreground">{edu.institution}</p>
                <div className={`mt-3 flex flex-wrap gap-3 text-xs text-muted-foreground ${i % 2 === 0 ? 'md:justify-end' : ''}`}>
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {edu.location}
                  </span>
                  <span className="flex items-center gap-1 font-semibold text-foreground">
                    <Award className="h-3 w-3 text-primary" />
                    {edu.score}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

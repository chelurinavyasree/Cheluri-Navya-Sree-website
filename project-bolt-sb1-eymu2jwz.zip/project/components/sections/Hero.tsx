'use client';

import { useEffect, useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Download, FolderGit2, Mail, Phone, ArrowDown, Linkedin, Github } from 'lucide-react';
import Image from 'next/image';
import { PERSONAL } from '@/lib/data';

function useTypingAnimation(words: string[], typeSpeed = 100, deleteSpeed = 50, pause = 2000) {
  const [text, setText] = useState('');
  const [wordIndex, setWordIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const word = words[wordIndex % words.length];
    const timeout = setTimeout(
      () => {
        if (!deleting) {
          setText(word.slice(0, text.length + 1));
          if (text === word) {
            setTimeout(() => setDeleting(true), pause);
          }
        } else {
          setText(word.slice(0, text.length - 1));
          if (text === '') {
            setDeleting(false);
            setWordIndex((i) => i + 1);
          }
        }
      },
      deleting ? deleteSpeed : typeSpeed
    );
    return () => clearTimeout(timeout);
  }, [text, deleting, wordIndex, words, typeSpeed, deleteSpeed, pause]);

  return text;
}

function Particles() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let particles: { x: number; y: number; vx: number; vy: number; size: number; alpha: number }[] = [];

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      const count = Math.min(60, Math.floor((canvas.width * canvas.height) / 20000));
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        size: Math.random() * 2 + 0.5,
        alpha: Math.random() * 0.5 + 0.2,
      }));
    };
    resize();
    window.addEventListener('resize', resize);

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particles.forEach((p, i) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(217, 91%, 60%, ${p.alpha})`;
        ctx.fill();

        for (let j = i + 1; j < particles.length; j++) {
          const q = particles[j];
          const dx = p.x - q.x;
          const dy = p.y - q.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(q.x, q.y);
            ctx.strokeStyle = `hsla(217, 91%, 60%, ${0.15 * (1 - dist / 120)})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      });

      animationId = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />;
}

export function Hero() {
  const typedText = useTypingAnimation(PERSONAL.roles);

  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center justify-center overflow-hidden pt-20"
    >
      {/* Background layers */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/5" />
        <div className="absolute left-1/4 top-1/4 h-96 w-96 rounded-full bg-primary/20 blur-[120px] animate-pulse-glow" />
        <div className="absolute right-1/4 bottom-1/4 h-96 w-96 rounded-full bg-accent/20 blur-[120px] animate-pulse-glow" style={{ animationDelay: '2s' }} />
        <Particles />
      </div>

      {/* Floating geometric elements */}
      <motion.div
        className="absolute left-[10%] top-[20%] hidden md:block"
        animate={{ y: [0, -30, 0], rotate: [0, 180, 360] }}
        transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
      >
        <div className="h-16 w-16 rounded-2xl border border-primary/30 glass" />
      </motion.div>
      <motion.div
        className="absolute right-[10%] top-[30%] hidden md:block"
        animate={{ y: [0, 20, 0], rotate: [0, -180, -360] }}
        transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
      >
        <div className="h-12 w-12 rounded-full border border-accent/30 glass" />
      </motion.div>
      <motion.div
        className="absolute right-[15%] bottom-[25%] hidden md:block"
        animate={{ y: [0, -25, 0] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
      >
        <div className="h-8 w-8 rotate-45 border border-primary/40 glass" />
      </motion.div>

      <div className="relative z-10 mx-auto max-w-4xl px-4 text-center md:px-8">
        {/* Profile photo */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="mb-8 flex justify-center"
        >
          <div className="relative">
            {/* Glow ring */}
            <div className="absolute inset-0 -z-10 animate-pulse-glow rounded-full bg-gradient-to-br from-primary/40 to-accent/40 blur-xl" />
            {/* Rotating gradient ring */}
            <div className="absolute -inset-2 -z-10 animate-spin-slow rounded-full bg-gradient-to-r from-primary via-accent to-primary opacity-60 blur-sm" />
            <div className="relative h-32 w-32 overflow-hidden rounded-full border-4 border-background shadow-2xl shadow-primary/30 md:h-40 md:w-40">
              <Image
                src="/WhatsApp_Image_2026-07-03_at_18.00.34.jpeg"
                alt="Cheluri Navya Sree"
                fill
                className="object-cover object-top"
                priority
                sizes="160px"
              />
            </div>
          </div>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mb-4 text-lg text-muted-foreground md:text-xl"
        >
          Hello, I&apos;m
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="font-space text-4xl font-bold tracking-tight sm:text-6xl md:text-7xl"
        >
          <span className="gradient-text-bright">{PERSONAL.displayName}</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-6 flex items-center justify-center gap-2 text-xl text-foreground md:text-2xl"
        >
          <span className="text-muted-foreground">Aspiring</span>
          <span className="font-space font-semibold text-primary min-w-[280px] text-left">
            {typedText}
            <span className="ml-0.5 inline-block w-0.5 bg-primary animate-blink" style={{ height: '1em' }} />
          </span>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mx-auto mt-8 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg text-balance"
        >
          {PERSONAL.summary}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <a
            href={PERSONAL.resumeUrl}
            download
            className="group flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/30 transition-all hover:scale-105 hover:shadow-primary/50"
          >
            <Download className="h-4 w-4 transition-transform group-hover:translate-y-0.5" />
            Download Resume
          </a>
          <button
            onClick={() => scrollTo('#projects')}
            className="group flex items-center gap-2 rounded-full glass px-6 py-3 text-sm font-semibold transition-all hover:scale-105 hover:glow-border"
          >
            <FolderGit2 className="h-4 w-4" />
            View Projects
          </button>
          <button
            onClick={() => scrollTo('#contact')}
            className="group flex items-center gap-2 rounded-full glass px-6 py-3 text-sm font-semibold transition-all hover:scale-105 hover:glow-border"
          >
            <Mail className="h-4 w-4" />
            Contact Me
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-10 flex items-center justify-center gap-4"
        >
          {PERSONAL.linkedin && (
            <a
              href={PERSONAL.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-11 w-11 items-center justify-center rounded-full glass transition-all hover:scale-110 hover:glow-border"
              aria-label="LinkedIn"
            >
              <Linkedin className="h-5 w-5" />
            </a>
          )}
          {PERSONAL.github && (
            <a
              href={PERSONAL.github}
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-11 w-11 items-center justify-center rounded-full glass transition-all hover:scale-110 hover:glow-border"
              aria-label="GitHub"
            >
              <Github className="h-5 w-5" />
            </a>
          )}
          <a
            href={`mailto:${PERSONAL.email}`}
            className="flex h-11 w-11 items-center justify-center rounded-full glass transition-all hover:scale-110 hover:glow-border"
            aria-label="Email"
          >
            <Mail className="h-5 w-5" />
          </a>
          <a
            href={`tel:${PERSONAL.phone}`}
            className="flex h-11 w-11 items-center justify-center rounded-full glass transition-all hover:scale-110 hover:glow-border"
            aria-label="Phone"
          >
            <Phone className="h-5 w-5" />
          </a>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <button
          onClick={() => scrollTo('#about')}
          className="flex flex-col items-center gap-2 text-muted-foreground transition-colors hover:text-primary"
          aria-label="Scroll down"
        >
          <span className="text-xs uppercase tracking-widest">Scroll</span>
          <div className="flex h-9 w-5 justify-center rounded-full border-2 border-current p-1">
            <div className="h-2 w-1 rounded-full bg-current animate-scroll-bounce" />
          </div>
          <ArrowDown className="h-4 w-4 animate-scroll-bounce" />
        </button>
      </motion.div>
    </section>
  );
}

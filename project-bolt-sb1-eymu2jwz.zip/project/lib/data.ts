import {
  Code2,
  Database,
  Brain,
  GitBranch,
  Globe,
  Eye,
  Cpu,
  Lightbulb,
  type LucideIcon,
} from 'lucide-react';

export const PERSONAL = {
  name: 'Navya Sree Cheluri',
  displayName: 'CHELURI NAVYA SREE',
  title: 'Aspiring AI/ML Engineer',
  roles: [
    'AI/ML Engineer',
    'Software Developer',
    'Python Developer',
    'Artificial Intelligence Enthusiast',
  ],
  summary:
    'I am a passionate B.Tech student specializing in Artificial Intelligence and Machine Learning at Annamacharya Institute of Technology and Sciences. With a strong academic background and a CGPA of 9.01, I am interested in Artificial Intelligence, Machine Learning, Software Development, Data Science, and problem-solving. I enjoy building practical technology solutions using Python, Java, SQL, computer vision, and machine learning while continuously learning modern technologies.',
  email: 'chelurinavyasree@gmail.com',
  phone: '+91 9398097381',
  location: 'Madanapalli, Andhra Pradesh - 517325, India',
  resumeUrl: '/Navya_Sree_Resume.pdf',
  linkedin: null as string | null,
  github: null as string | null,
};

export const NAV_LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Education', href: '#education' },
  { label: 'Experience', href: '#experience' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Certifications', href: '#certifications' },
  { label: 'Achievements', href: '#achievements' },
  { label: 'Resume', href: '#resume' },
  { label: 'Contact', href: '#contact' },
];

export const STATS = [
  { value: 9.01, suffix: '', label: 'Current CGPA' },
  { value: 98, suffix: '%', label: 'Secondary Education' },
  { value: 7, suffix: '+', label: 'Projects Built' },
  { value: 3, suffix: '', label: 'Certifications' },
];

export const EDUCATION = [
  {
    degree: 'Bachelor of Technology',
    branch: 'Artificial Intelligence and Machine Learning',
    institution: 'Annamacharya Institute of Technology and Sciences',
    duration: '2023 – 2027',
    location: 'Rajampet, Andhra Pradesh',
    score: 'CGPA: 9.01',
  },
  {
    degree: 'Intermediate',
    branch: 'MPC',
    institution: 'Sri Sai Siddhartha Junior College',
    duration: '2021 – 2023',
    location: 'Madanapalli, Andhra Pradesh',
    score: 'Percentage: 92.3%',
  },
  {
    degree: 'Secondary Education',
    branch: '',
    institution: 'Z.P. High School',
    duration: '2021',
    location: 'Burakayalakota, Andhra Pradesh',
    score: 'Percentage: 98%',
  },
];

export const EXPERIENCE = [
  {
    title: 'AlgoUniversity Technology Fellowship (ATF) 2025',
    status: '2026 – Present',
    focusAreas: [
      'Data Structures & Algorithms',
      'Python',
      'Java',
      'DevOps',
      'Git',
      'GitHub',
    ],
    description:
      'Currently attending classes on Data Structures & Algorithms and DevOps, learning problem-solving techniques and software development concepts, gaining practical knowledge of Git and GitHub fundamentals, and improving coding and analytical thinking skills.',
  },
];

export interface SkillCategory {
  title: string;
  icon: LucideIcon;
  skills: string[];
}

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    title: 'Programming Languages',
    icon: Code2,
    skills: ['Java', 'Java OOPs', 'Python', 'SQL', 'HTML', 'CSS', 'JavaScript'],
  },
  {
    title: 'AI & Machine Learning',
    icon: Brain,
    skills: [
      'Machine Learning',
      'Scikit-learn',
      'Pandas',
      'NumPy',
      'Natural Language Processing',
      'Computer Vision',
      'OpenCV',
      'MediaPipe',
    ],
  },
  {
    title: 'Database',
    icon: Database,
    skills: ['MySQL', 'DBMS', 'JDBC', 'SQL'],
  },
  {
    title: 'Development Tools',
    icon: GitBranch,
    skills: ['Git', 'GitHub', 'VS Code', 'JavaFX', 'MS Word'],
  },
  {
    title: 'AI & Edge Technologies',
    icon: Cpu,
    skills: [
      'TensorFlow Lite',
      'ONNX',
      'OpenVINO',
      'TinyML',
      'Model Optimization',
    ],
  },
  {
    title: 'Web & Frontend',
    icon: Globe,
    skills: ['HTML', 'CSS', 'JavaScript', 'React.js'],
  },
  {
    title: 'Data & Analysis',
    icon: Eye,
    skills: ['Data Analysis', 'Data Structures & Algorithms'],
  },
  {
    title: 'Soft Skills',
    icon: Lightbulb,
    skills: [
      'Problem Solving',
      'Communication',
      'Leadership',
      'Teamwork',
      'Critical Thinking',
      'Adaptability',
      'Time Management',
    ],
  },
];

export interface Project {
  title: string;
  year: string;
  technologies: string[];
  description: string;
  features: string[];
  visual: 'ai' | 'database' | 'agriculture' | 'voice' | 'sorting' | 'task' | 'concentration';
  github?: string;
  demo?: string;
}

export const PROJECTS: Project[] = [
  {
    title: 'AI-Enabled Drone-Based Precision Agriculture Framework for Real-Time Crop Disease Detection and Automated Pesticide Spraying',
    year: '2025',
    technologies: [
      'Python',
      'Artificial Intelligence',
      'Machine Learning',
      'Computer Vision',
      'YOLOv11',
      'EfficientNet-B3',
      'XGBoost',
      'Grad-CAM',
      'OpenCV',
      'NVIDIA Jetson Orin Nano',
      'UAV / Drone Technology',
      'GPS',
      'IoT Sensors',
    ],
    description:
      'Developed an AI-enabled precision agriculture framework that uses drone imagery and environmental sensor data to detect crop diseases in real time, estimate disease severity, identify probable causes, and support intelligent targeted pesticide spraying.',
    features: [
      'Real-time crop disease detection',
      'Disease severity classification',
      'Environmental condition monitoring',
      'Temperature and humidity monitoring',
      'Rainfall and wind speed monitoring',
      'Soil moisture, soil pH, and NPK monitoring',
      'GPS-based disease localization',
      'AI-powered probable cause analysis',
      'Explainable AI using Grad-CAM',
      'Variable-rate pesticide spraying',
      'Offline edge AI inference',
      'Mobile application alerts and recommendations',
    ],
    visual: 'agriculture',
  },
  {
    title: 'AI-Based Voice Assistant for Students',
    year: '2025',
    technologies: [
      'Python',
      'SpeechRecognition',
      'pyttsx3',
      'Wikipedia API',
      'OpenAI API',
      'Streamlit',
    ],
    description:
      'Developed an AI-powered academic voice assistant that helps students access study materials, obtain answers, and manage academic information using voice-based interaction.',
    features: [
      'Voice Recognition',
      'Text-to-Speech',
      'AI-Based Question Answering',
      'Academic Assistance',
      'Study Material Access',
      'Interactive Streamlit Interface',
    ],
    visual: 'voice',
  },
  {
    title: 'Concentration Detector-AI',
    year: '2025',
    technologies: ['Python', 'OpenCV', 'MediaPipe', 'NumPy'],
    description:
      'Created a real-time focus detection system using OpenCV and MediaPipe. Detected user distraction through eye and head movement analysis with live alerts.',
    features: [
      'Real-time webcam processing',
      'Eye movement analysis',
      'Head movement analysis',
      'Face detection',
      'Facial landmark tracking',
      'Attention monitoring',
      'Live distraction alerts',
      'Computer vision-based analysis',
    ],
    visual: 'concentration',
  },
  {
    title: 'Student Management System – GUI-based Desktop Application',
    year: 'July 2025',
    technologies: ['Java', 'JavaFX', 'MySQL', 'JDBC'],
    description:
      'Built a modular desktop application to manage student records using JavaFX and MySQL. Integrated database operations with JDBC for real-time CRUD functionality.',
    features: [
      'Real-time CRUD functionality',
      'Database operations using JDBC',
      'GUI-based desktop interface',
      'Object-Oriented Programming',
      'Input validation',
      'Error handling',
      'Scalable and usable design',
    ],
    visual: 'database',
  },
  {
    title: 'Sorting Visualization Web Application',
    year: '2025',
    technologies: ['HTML', 'CSS', 'JavaScript'],
    description:
      'Developed an interactive web application that visually demonstrates sorting algorithms to help users understand algorithmic concepts.',
    features: [
      'Interactive sorting visualizations',
      'Step-by-step algorithm demonstration',
      'Multiple sorting algorithm support',
      'Real-time animation',
      'Beginner-friendly UI',
    ],
    visual: 'sorting',
  },
  {
    title: 'Task Manager Application',
    year: '2025',
    technologies: ['Java', 'JavaFX'],
    description:
      'Developed a desktop-based task management application with a graphical user interface for creating, managing, and organizing tasks.',
    features: [
      'Create and manage tasks',
      'Organize tasks by priority',
      'GUI-based desktop interface',
      'Task status tracking',
      'Object-Oriented design',
    ],
    visual: 'task',
  },
  {
    title: 'Student Management System',
    year: '2025',
    technologies: ['Java', 'MySQL', 'JDBC'],
    description:
      'Developed a Java-based Student Management System for managing student records using MySQL database connectivity through JDBC.',
    features: [
      'CRUD Operations',
      'Database Connectivity via JDBC',
      'Input Validation',
      'Object-Oriented Programming',
      'Structured record management',
    ],
    visual: 'ai',
  },
];

export const CERTIFICATIONS = [
  {
    name: 'Python Programming for AI — Capstone Project Certificate',
    organization: 'Sri Vensy Technologies Pvt. Ltd.',
    date: '27 June 2026',
    grade: 'A',
    duration: '15 Days',
    role: 'AI/ML Engineer',
    projectTitle: 'AI-Based Security Surveillance System',
    technologies: ['Python', 'Django', 'HTML', 'CSS', 'JavaScript', 'Bootstrap', 'SQLite', 'Git'],
    skills: ['Frontend Development', 'Backend Development', 'Database Integration', 'REST APIs', 'User Authentication', 'Deployment'],
    cin: 'U72900AP2022PTC123207',
    type: 'capstone' as const,
  },
  {
    name: 'AlgoUniversity Tech Fellowship (ATF 2025)',
    organization: 'AlgoUniversity',
    date: '2025',
    grade: null,
    duration: null,
    role: null,
    projectTitle: null,
    technologies: [],
    skills: ['Data Structures & Algorithms', 'Python', 'Java', 'DevOps', 'Git', 'GitHub'],
    cin: null,
    description: 'Selected for ATF 2025 for outstanding performance in the AlgoUniversity Tech Fellowship (ATF) 2025.',
    type: 'fellowship' as const,
  },
  {
    name: 'Cloud Computing (AWS) & DevOps',
    organization: 'Job Prep',
    date: null,
    grade: null,
    duration: null,
    role: null,
    projectTitle: null,
    technologies: [],
    skills: [],
    cin: null,
    type: 'online' as const,
  },
  {
    name: 'Introduction to Python',
    organization: 'Simple Learn',
    date: null,
    grade: null,
    duration: null,
    role: null,
    projectTitle: null,
    technologies: [],
    skills: [],
    cin: null,
    type: 'online' as const,
  },
  {
    name: 'Full Stack Web Development',
    organization: 'Pantech.AI',
    date: null,
    grade: null,
    duration: null,
    role: null,
    projectTitle: null,
    technologies: [],
    skills: [],
    cin: null,
    type: 'online' as const,
  },
];

export const ACHIEVEMENTS = [
  {
    title: 'AlgoUniversity Tech Fellowship (ATF 2025)',
    description: 'Selected for ATF 2025 for outstanding performance in the AlgoUniversity Tech Fellowship. Recognised by Manas Kumar Verma (Founder & CEO, AlgoUniversity) and Twapnil Daga (Head of Teaching).',
    icon: 'fellowship' as const,
    year: '2025',
  },
  {
    title: 'NCC Certificate — A & B',
    description: 'National Cadet Corps A and B Certificate holder.',
    icon: 'ncc' as const,
    year: '',
  },
  {
    title: 'Sports Certificate — SoftBall',
    description: 'Represented at Zonal Level in SoftBall.',
    icon: 'sports' as const,
    year: '',
  },
];
